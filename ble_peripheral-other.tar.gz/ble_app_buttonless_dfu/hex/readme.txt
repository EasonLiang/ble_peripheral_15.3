You can find hex files of this example in examples/dfu/secure_dfu_test_images.
These hex files include everything needed for it to run, including a bootloader.
You will also find images to transfer via DFU.
